# Trabalho 2 de OAC

## Execute o programa da seguinte forma:

``` gcc trabalho2.c```

``` ./a.out ```


